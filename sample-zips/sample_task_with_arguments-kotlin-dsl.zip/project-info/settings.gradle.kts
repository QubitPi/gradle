rootProject.name = "project-info"
