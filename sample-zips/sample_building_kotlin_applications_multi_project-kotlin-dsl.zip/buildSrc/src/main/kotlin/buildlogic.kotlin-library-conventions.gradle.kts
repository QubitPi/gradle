plugins {
    id("buildlogic.kotlin-common-conventions") // <1>
    `java-library` // <2>
}
