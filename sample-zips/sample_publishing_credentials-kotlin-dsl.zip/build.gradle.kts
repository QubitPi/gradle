plugins {
    `java-library`
    `maven-publish`

    // this plugin comes from an included build - it fakes a maven repository to allow executing the authentication flow
    id("maven-repository-stub")
}

version = "1.0.2"
group = "com.example"

publishing {
    publications {
        create<MavenPublication>("library") {
            from(components.getByName("java"))
        }
    }
    repositories {
        maven {
            name = "mySecureRepository"
            credentials(PasswordCredentials::class)
            // url = uri(<<some repository url>>)
        }
    }
}
