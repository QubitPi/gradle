rootProject.name = "multi-project-with-toolchains"
include("application", "list", "utilities")
