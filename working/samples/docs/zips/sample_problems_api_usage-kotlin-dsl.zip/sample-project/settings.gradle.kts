rootProject.name = "sample-project"

includeBuild("../reporters/standard-plugin")
includeBuild("../reporters/script-plugin")
