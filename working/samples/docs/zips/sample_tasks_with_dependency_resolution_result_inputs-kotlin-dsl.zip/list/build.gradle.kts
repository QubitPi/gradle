plugins {
    id("java-library")
}
