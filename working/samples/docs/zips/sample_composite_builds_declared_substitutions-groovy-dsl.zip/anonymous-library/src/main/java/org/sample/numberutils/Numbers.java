package org.sample.numberutils;

public class Numbers {
   public static int add(int left, int right) { return left + right; }
}
