plugins {
    `kotlin-dsl`
}

repositories {
    gradlePluginPortal()
}
