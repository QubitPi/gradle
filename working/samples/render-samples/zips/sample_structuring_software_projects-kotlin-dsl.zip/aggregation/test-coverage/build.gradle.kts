plugins {
    id("com.example.report-aggregation")
}

dependencies {
    // Transitively collect coverage data from all features and their dependencies
    aggregate("com.example.myproduct.user-feature:table")
    aggregate("com.example.myproduct.admin-feature:config")
}
