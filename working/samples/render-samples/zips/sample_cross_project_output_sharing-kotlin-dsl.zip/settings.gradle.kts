rootProject.name = "sharing-outputs"
include("producer")
include("consumer")
