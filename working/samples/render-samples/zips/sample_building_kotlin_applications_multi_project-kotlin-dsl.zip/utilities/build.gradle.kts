plugins {
    id("buildlogic.kotlin-library-conventions")
}

dependencies {
    api(project(":list"))
}
