plugins {
    id("reporters.model.builder")
}
