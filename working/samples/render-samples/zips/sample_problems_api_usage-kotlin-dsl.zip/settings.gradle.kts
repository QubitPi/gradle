rootProject.name = "gradle-problems-sample"

includeBuild("sample-ide")
includeBuild("sample-project")
includeBuild("reporters/standard-plugin")
includeBuild("reporters/script-plugin")
includeBuild("reporters/model-builder-plugin")

