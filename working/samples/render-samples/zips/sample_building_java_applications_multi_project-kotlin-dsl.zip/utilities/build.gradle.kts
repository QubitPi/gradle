plugins {
    id("buildlogic.java-library-conventions")
}

dependencies {
    api(project(":list"))
}
