plugins {
    id("buildlogic.groovy-library-conventions")
}
